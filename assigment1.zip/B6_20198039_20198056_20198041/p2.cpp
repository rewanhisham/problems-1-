#include <iostream>
#include <climits>
using namespace std;
/* run this program using the console pauser or add your own getch, system("pause") or input loop */
void swap(int* v1, int* v2)
{
	int temp = *v1;
	*v1 = *v2;
	*v2 = temp;
}

int partition(int arr[], int left, int right)
{
	int val = arr[right], co= left;
	for (int j = left; j <= right - 1; j++) {
		if (arr[j] <= val) {
			swap(&arr[co], &arr[j]);
			co++;
		}
	}
	swap(&arr[co], &arr[right]);
	return co;
}

int kthSmallest(int arr[], int left, int right, int k)
{
	
	if (k > 0 && k <= right - left + 1)
	{
		int pos = partition(arr, left, right);
		if (pos - left == k - 1)
			return arr[pos];
		if (pos - left > k - 1) 
		{
			return kthSmallest(arr, left, pos - 1, k);
		}
	
		return kthSmallest(arr, pos + 1, right, k - pos + left - 1);
	}
	return INT_MAX;
}
long long m_w,m_z;
int getrondom()
{
	m_z=36969*(m_z&65535)+(m_z>>16);
	m_w=18000*(m_w&65535)+(m_w>>16);
	long long res=(m_z<<16)+m_w;
	return res% 1000000000;
}
void printarray(int arr[],int size)
{
	cout<<"your array elemnt is:{";
	for(int i=0;i<size;i++)
	{
		cout<<arr[i];
		if(i<size-1)
		{
			cout<<" , ";
		}
	}
	cout<<" }\n";
}
int main(int argc, char** argv) {
	int n,k;
	cout<<"enter the array size, k'th , m_w,m_z in order :";
	cin>>n>>k>>m_w>>m_z;
	int arr[n];
	for(int i=0;i<n;i++)
	{
		arr[i]=getrondom();
	}
	printarray(arr,n);
	cout << "\nK'th smallest element is " << kthSmallest(arr, 0, n - 1, k);
	return 0;
}
