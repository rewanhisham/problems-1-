#include <iostream>
using namespace std;
/* run this program using the console pauser or add your own getch, system("pause") or input loop */
void swap(int *x, int *y) 
{ 
    int temp = *x; 
    *x = *y; 
    *y= temp; 
} 
void insertionSort(int arr[], int size)
{
	int i,j;
	int val;
	int count=0;
	for (i = 1; i < size; i++)
	{
		val= arr[i];
		j=i-1;
		while (j >= 0&& arr[j] >val)
		{
			
			arr[j + 1] = arr[j];
			count++;
			j=j-1;
			
		}
		arr[j+1] =val;
	}
	cout<<"number of swaps= "<<count;
}
int main(int argc, char** argv)
{
	int size;
	int arr[size];
	cout<<"please enter the array size: ";
	cin>>size;
	cout<<"enter your array item:\n";
	for(int i=0;i<size;i++)
	{
		cin>>arr[i];
	}
	insertionSort(arr, size);
	return 0;
}
