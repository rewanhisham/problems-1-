/******************************************************************************

                              Online C++ Compiler.
               Code, Compile, Run and Debug C++ program online.
Write your code in this editor and press "Run" button to compile and execute it.

*******************************************************************************/
#include <bits/stdc++.h>
#include <iostream>
using namespace std;
const int maxi = 100000;
int arr[maxi];
int query(int l, int r, int m)
{
 if (l > r) 
 {
  return 0;
 }
 if (l == r)
 {
  return (arr[l]-m > 0);
 }
 int index = l;
 int c = 0;
 for (int i=l+1;i<=r;i++)
 {
     if(arr[i]<arr[index])
     {
        index=i;
     }
 }
 return min(r-l+ 1,arr[index]-m + query(l, index- 1,arr[index])+query(index + 1, r, arr[index]));
}

void mult(int n)
{
  cout<<query(1, n, 0);
}

int main() {
    int n;
    int count= 1;
    cout<<"please enter your size: ";
    cin>>n;
    for (int i = 1; i <= n; ++i) 
    {
       cin>>arr[i];
    }
    while (count>0)
    {
       mult(n);
       count--;
    }
 return 0;
}
