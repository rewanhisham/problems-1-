#include <iostream> 
#include <unordered_map> 
using namespace std; 
/* run this program using the console pauser or add your own getch, system("pause") or input loop */ 
void rearrange(int arr[], int n) 
{ 
    unordered_map <int, int> rep; 
    for (int i=0;i<n; i++)
	{ 
        rep[arr[i]]++; 
    } 

    for (int i=0;i<n;i++) 
    { 
        if (rep.find(arr[i])!=rep.end()) 
        { 
            int val=rep[arr[i]]; 
            while (val>0)
			{ 
                cout <<arr[i]<<" ";
				val--;
            } 
            rep.erase(arr[i]); 
        } 
    }
} 
int main(int argc, char** argv) { 
    int size; 
    cout<<"please enter your array size: "; 
    cin>>size; 
    int arr[size]; 
    cout<<"please enter your array elemnt:"; 
    for(int i=0;i<size;i++) 
    { 
        cin>>arr[i]; 
    } 
    rearrange(arr, size); 
 return 0; 
}
