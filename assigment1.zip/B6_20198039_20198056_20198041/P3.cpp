//PROBLEM 3
#include <iostream>
//#include<cstring>
using namespace std;
int Merge(int* arr, int l, int m, int r)
{
	int Count = 0;

	int lenL = m - l + 1;
	int lenR = r - m;

	int* left = new int[lenL];
	int* right = new int[lenR];

	for (int i = 0; i < lenL; ++i)
	{
		left[i] = arr[l + i];
	}

	for (int i = 0; i < lenR; ++i)
	{
		right[i] = arr[m + 1 + i];
	}

	int i = 0, j = 0, k = l;

	while (i < lenL && j < lenR)
	{
		if (left[i] < right[j])
			arr[k++] = left[i++];
		else
		{
			arr[k++] = right[j++];
			Count += lenL - i;
		}
	}

	while (i < lenL)
		arr[k++] = left[i++];

	while (j < lenR)
		arr[k++] = right[j++];

	delete[] left;
	delete[] right;

	return Count;
}
int MergeSort(int* arr, int l, int r)
{
	int Count = 0;

	if (l < r)
	{
		int mid = l + (r - l) / 2;

		Count += MergeSort(arr, l, mid);
		Count += MergeSort(arr, mid + 1, r);

		Count += Merge(arr, l, mid, r);
	}

	return Count;
}

int arrInversion(int arr[], int n) 
{

   return MergeSort(arr, 0, n-1);
}
void createarr()
{
	int n;
    cout<<"please enter your array size: ";
    cin>>n;
    int arr[n];
    cout<<"please enter your array element:";
    for(int i=0; i<n; i++)
    {
        cin>>arr[i];
    }

cout<<arrInversion( arr, n);
}
int main()
{
    createarr();
}
