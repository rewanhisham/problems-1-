#include <iostream>
#include<bits/stdc++.h>
using namespace std;
void findMinRepeatIndex(int arr[], int n)
{
    int minIndex = n;
    set<int> Set;
    for (int i = n - 1; i >= 0; i--)
    {
        if (Set.find(arr[i]) != Set.end())
        {
            minIndex = i;
        }
        else
        {
            Set.insert(arr[i]);
        }
    }
    if (minIndex!=n)
    {
    	cout<<"The minimum index of the repeating element is " << minIndex;
    }
    else
    {
    	cout<<"invalid input ";
	}
    
}

int main()
{
    int size;
	cout<<"please enter your size: ";
	cin>>size;
	int arr[size];
	cout<<"please enter your array elemnt:\n";
	for(int i=0;i<size;i++)
	{
		cin>>arr[i];
	}
    findMinRepeatIndex(arr, size);
    return 0;
}
