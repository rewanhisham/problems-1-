#include <iostream>
#include <stdio.h>
using namespace std;
/* run this program using the console pauser or add your own getch, system("pause") or input loop */
/*we will represent defected toies with number "0" and nondefected with number "1" ,all toies is sorted so we can use binary search tree
that will help us to know the index of the first defected toy with time complexity o(logn),in this algorithm we will use to varibles one 
in the first elemnt of the array(low) and the other on the last elemnt in array(size-1)(deep), 
then we will enter a while loop that will still work if low<deep then creat variable to catch the midel in every itreation (m)=(low+deep)/2
then search if arr[m] =0 or 1 if =1 that is mean all toies before the mid is nondefected so it will increase the low with m+1 and go while condation 
then count m if the condation is true,else if after it count m and find the condition of else if is true it will make deep=m-1 to find the first defected toy
when low>deep that is mean he find the first defected toy so it will go for return line */
int binarySearch(int values[], int size)
{
    int low=0;
	int deep=size-1;
    while (low <= deep)
    {
        int m= (low + deep)/2;    
        if (values[m]==1)
		{
            low= m+1;
        }
        else if(values[m]==0)
		{
            deep=m-1;
        }
        /*else
		{
            m;
        }*/
    }
    return deep+1;
}
int main(void)
{
    int values[] ={1,1,1,0,0,0,0,0};
    int size = sizeof(values)/sizeof(values[0]);
    int i = binarySearch(values, size);
    if (i != -1) 
	{
        cout<<"Element found at index:"<<i;
    }
    else
	{
        cout<<"Element not found in the array";
    }
    return 0;
}
