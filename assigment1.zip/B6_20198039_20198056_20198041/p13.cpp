
                              Online C++ Compiler.
               Code, Compile, Run and Debug C++ program online.
Write your code in this editor and press "Run" button to compile and execute it.

*******************************************************************************/
#include<stdio.h>
#include<iostream>
using namespace std;
/* run this program using the console pauser or add your own getch, system("pause") or input loop */

int first[12][12] = {}, w, x, y, z;
int sec[12][12] = {};
void Backtracking(int left, int right)
 {
	if(left+1<right)
	{
		int mid = sec[left][right];
		printf("(");
		Backtracking(left, mid);
		printf(" x ");
		Backtracking(mid+1, right);
		printf(")");
	}
	if(right == left)
		printf("A%d", left+1);
	if(right==left+1 )
		printf("(A%d x A%d)", left+1, right+1);
}

int main(int argc, char** argv) 
{
	int num, Arr[12], Const= 0;
	while(scanf("%d", &num) == 1 && num) {

		for(w= 0; w < num; w++)
			scanf("%d %d", &Arr[w], &Arr[w+1]);
		for(w = 1; w < num; w++) {
			for(x= 0, y= w + x; y < num; x++, y++) {
				int min =100000000, val, k;
				for(z= x; z< y; z++) {
					val= first[x][z] + first[z+1][y] + Arr[x]*Arr[z+1]*Arr[y+1];
					if(min > val) {
						min = val, k = z;
					}
				}
				first[x][y] = min, sec[x][y] = k;
			}
		}
		printf("Case %d: ", ++Const);
		Backtracking(0, num-1);
		puts("");
	}
	return 0;
}
