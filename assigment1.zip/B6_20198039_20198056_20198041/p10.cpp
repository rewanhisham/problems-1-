#include <iostream>

/* run this program using the console pauser or add your own getch, system("pause") or input loop */
using namespace std;
struct node 
{
	int key;
	struct node *l;
	struct node *r;
	int lchild;
	int rchild;
	int height;
};
int max (int a, int b)
{
    if(a>b)
    {
        return a;
    }
    else
    {
        return b;
    }
}
 
int height (node *root) 
{
    if (root== NULL)
    {
        return 0;
    }
    else
    {
        return root -> height;
    }
}
 
node *newnode (int key, int lchild, int rchild) 
{
	node *tmp=(node *) malloc( sizeof(node));
	tmp ->key=key;
	tmp ->l=NULL;
	tmp ->r=NULL;
	tmp ->height=1;
	tmp ->lchild=lchild;
	tmp ->rchild=rchild;
	return tmp;
}
 
node *rightrotate (node *T)
{
	node *T1 = T->l;
	node *T2 = T1->r;
	T1 ->r = T;
	T ->l = T2;
	T ->height = max( height(T -> l), height(T -> r) ) + 1;
	T1 ->height = max( height(T1 -> l), height(T1 -> r) ) + 1;
	if (T2 != NULL)
	{
	    T -> lchild = T2 -> lchild + T2 -> rchild + 1;
	 }
	else 
	{
	    T -> lchild = 0;
	}
	T1 ->rchild=T2 ->lchild+T->rchild+1;
	return T1;
}
node *leftrotate (node *T1) {
	node *T = T1 -> r;
	node *T2 = T -> l;
 
	T -> l= T1;
	T1-> r= T2;
 
	T1 ->height = max( height(T1 -> l), height(T1 -> r) ) + 1;
	T ->height = max( height(T -> l), height(T -> r) ) + 1;
	if (T2 != NULL) 
	{
	    T1 -> rchild = T2 -> lchild + T2 -> rchild + 1;
	    
	} 
	else
	{ 
	    T1 -> rchild = 0;
	    
	}
	T-> lchild = T1 -> lchild + T1 -> rchild + 1;
	return T;
}
int getbalance(node *root)
{
	if (root == NULL) 
	{
	    return 0;
	}
	else 
	{
	    return height(root -> l) - height(root -> r);
	}
}
 
node *insert(node *root, int key) {
	if (root==NULL) 
	{
	    return newnode(key, 0, 0);
	}
	if (key <root->key) 
	{
		root ->l=insert(root -> l, key);
		root ->lchild++;
	}
	else if (key > root->key)
	{
		root -> r = insert(root->r, key);
		root -> rchild++;
	}
	else
	{
	    return root;
	}
	root -> height = max( height(root -> l),height(root -> r) ) + 1;
	int balance = getbalance(root);
	if ( (balance > 1) && (key < root -> l -> key) )
	{
	    return rightrotate(root);
	}
	if ( (balance < -1) && (key > root -> r -> key) )
	{ 
	    return leftrotate(root);
	}
	if ( (balance > 1) && (key > root -> l -> key) )
	{
		root -> l = leftrotate(root -> l);
		return rightrotate(root);
	}
	if ( (balance < -1) && (key < root -> r -> key) )
	{
		root -> r = rightrotate(root -> r);
		return leftrotate(root);
	}
	return root;
}
int point;
int findkey (node *root, int key) {
	if (root != NULL)
	{
		if (key > root -> key) 
		{
		    return root -> lchild + 1 + findkey(root -> r, key);
		}
		else if (key < root -> key) 
		{
		    return findkey(root -> l, key);
		}
		else 
		{
		    return root -> lchild;
		}
	} 
	else 
	{
		point=1;
		return -1;
	};
}
node * minValueNode(node* Node)
{
    node* current = Node;
    while (current->l!= NULL)
        current = current->l;
    return current;
}
node* deleteNode(node* root, int key)
{
    if (root == NULL)
        return root;
    if ( key < root->key )
        root->l= deleteNode(root->l, key);
    else if( key > root->key )
        root->r= deleteNode(root->r, key);
    else
    {
        if( (root->l== NULL) || (root->r== NULL) )
        {
            node *temp = root->l ?root->l : root->r;
            if (temp==NULL)
            {
                temp = root;
                root = NULL;
            }
            else
            *root = *temp;
            
            free(temp);
        }
        else
		{
            node* temp = minValueNode(root->r);
            root->key = temp->key;
            root->r = deleteNode(root->r,temp->key);
        }
    }
    if (root == NULL)return root;
    root->height = 1 + max(height(root->l),height(root->r));
    int balance = getbalance(root);
    if (balance > 1 &&getbalance(root->l) >= 0)return rightrotate(root);
    if (balance > 1 &&getbalance(root->l) < 0)
    {
        root->l= leftrotate(root->l);
        return rightrotate(root);
    }
    if (balance < -1 &&getbalance(root->r) <= 0)
        return leftrotate(root);
    if (balance < -1 &&getbalance(root->r) > 0)
    {
        root->r= rightrotate(root->r);
        return leftrotate(root);
    }
    return root;
}
void order (node *root) 
{
	if (root != NULL) 
	{
		cout<< root -> key<< root ->lchild<< root -> rchild<<"\n";
		order(root -> l);
		order(root -> r);
	}
}
int findvalue(struct node *root,int tPos,int cPos)
{
    if(root != NULL)
    {
        int newP = findvalue(root->l, tPos, cPos);
        newP++;
        if (newP == tPos)
        {
            printf("%d\n", root->key);
        }
        return findvalue(root->r, tPos, newP);
    }
    else
    {
        return cPos;
    }
}
 
int main () {
	int n;
	//int arr[n];
	//int c=0;
	cin>>n;
	node *root = NULL;
	bool status=true;
	int k;
	int value;
	while(status) 
	{
		cin>>k>>value;
		if (k == 1) 
		{
			insert(root, value);
		}
		if (k == 2) 
		{
			deleteNode(root, value);
		}
		if(k== 3)
		{
		    point = 0;
			int index = findkey(root,value) + 1;
			//arr[c]=index;
			//c++;
			if (point!=0)
			{
			    cout<<-1; 
			    
			}
			else
			{
			    cout<<index;
		    }
		}
		if(k ==4)
		{
		    int pos=0;
		    pos=(root,value,0);
		    cout<<pos;
		}
		if(k==-1)
		{
		    status=false;
		}
	}
	/*for(int i=0;i<n/2;i++)
	{
		cout<<arr[i];
	}*/
	return 0;
}
