#include <bits/stdc++.h>
using namespace std;

void Pairs(int arr[], int size, int target)
{
	set<int> val;
	int count=0;
	for (int i = 0; i < size; i++)
	{
		int temp = target - arr[i];

		if (val.find(temp) != val.end())
		{
            cout << "Pairs found "<<target<<" is ("<<temp<<","<<arr[i]<<")\n";
            count++;
		}
		val.insert(arr[i]);
	}
	if(count==0)
	{
		cout<<"pair not found\n";
	}
}
int main()
{
	int size;
	cout<<"please enter your size: ";
	cin>>size;
	int arr[size];
	cout<<"please enter your array elemnt:\n";
	for(int i=0;i<size;i++)
	{
		cin>>arr[i];
	}
	int target;
	cout<<"please enter your target: ";
	cin>>target;
	Pairs(arr, size, target);
	return 0;
}
