#include <iostream>
#include<bits/stdc++.h>
//#include<graphics.h>
  using namespace std;

class Vector
{
    double v[3];
public:
    Vector()
    {
        v[0]=v[1];
        v[2]=1;
    }
    Vector(double x, double y)
    {
        v[0]=x;
        v[1]=y;
        v[2]=1;
    }
    double& operator[](int n)
    {
        return v[n];
    }
};
class Matrix
{
    Vector A[3];
public:
    Vector& operator[](int n)
    {
        return A[n];
    }
    friend Matrix operator*(Matrix& A,Matrix& B)
    {
        Matrix C;
        for(int i=0; i<3; i++)
            for(int j=0; j<3; j++)
            {
                C[i][j]=0;
                for(int k=0; k<3; k++)C[i][j]+=A[i][k]*B[k][j];
            }
        return C;
    }
    friend Vector operator*(Matrix& A,Vector& v)
    {
        Vector r;
        for(int i=0; i<3; i++)
        {
            r[i]=0;
            for(int j=0; j<3; j++)
                r[i]+=A[i][j]*v[j];
        }
        return r;
    }
    Matrix& operator*=(Matrix& B)
    {
        *this=*this*B;
        return *this;
    }
};
Matrix Identity()
{
    Matrix A;
    for(int i=0; i<3; i++)
        for(int j=0; j<3; j++)
            A[i][j]= i==j ;
    return A;
}
Matrix translate(double dx, double dy)
{
    Matrix T=Identity();
    T[0][2]=dx;
    T[1][2]=dy;
    return T;
}
Matrix scale(double a, double b)
{
    Matrix Sc=Identity();
    Sc[0][0]=a;
    Sc[1][1]=b;
    return Sc;
}

Matrix rotate(double theta)
{
    Matrix R=Identity();
    R[0][0]=R[1][1]=cos(theta);
    R[1][0]=sin(theta);
    R[0][1]=-R[1][0];
    return R;
}


