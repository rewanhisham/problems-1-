#include <iostream>
#include <bits/stdc++.h>
using namespace std;
/* run this program using the console pauser or add your own getch, system("pause") or input loop */
class Point
{
	public:
	int x;
	int y;
};
int funcompx(const void* a, const void* b )
{
	Point *p1=(Point *)a,*p2=(Point *)b;
	return (p1->x - p2->x);
}
int funcompy(const void* a, const void* b)
{
	Point *p1=(Point *)a,*p2=(Point *)b;
	return (p1->y-p2->y);
}
float distance(Point p1, Point p2)
{
	return sqrt((p1.x-p2.x)*(p1.x-p2.x)+(p1.y-p2.y)*(p1.y-p2.y));
}
float bruteForce(Point P[], int size)
{
	float smal=1000000000;
	for (int i=0;i<size;i++)
	{
		for (int j=i+1;j<size;j++)
		{
			if (distance(P[i], P[j])<smal)
				smal=distance(P[i],P[j]);
		}
	}
	return smal;
}
float min(float x, float y)
{
	if(x<y)
	{
	    return x;
	}
	else
	{
	    return y;
	}
}
float stripClosest(Point points[], int n, float k)
{
	float mini=k;
	qsort(points, n, sizeof(Point), funcompy);
	for (int i=0;i<n;i++)
	{
		for (int j=i+1;j<n&&(points[j].y-points[i].y)<mini;j++)
		{
			if (distance(points[i],points[j])<mini)
			{
				mini=distance(points[i],points[j]);
			}
		}
    }
	return mini;
}
float closestpear(Point P[], int num)
{
	if (num<=3)
	{
		return bruteForce(P,num);
	}
	int midel=num/2;
	Point midPoint=P[midel];
	float dleft=closestpear(P,midel);
	float dright=closestpear(P+midel,num-midel);
	float d=min(dleft,dright);
	Point points[num];
	int c=0;
	for (int i=0;i<num;i++)
	{
		if (abs(P[i].x-midPoint.x)<d)
		{
			points[c]=P[i];
			c++;
		}
	}
	return min(d, stripClosest(points, c, d) );
}
float closest(Point P[], int n)
{
	qsort(P,n,sizeof(Point),funcompx);
	return closestpear(P,n);
}

int main(int argc, char** argv) {
	
	Point Points[]={{5,8},{1,4},{60,30},{3,0},{14,9},{3,4}};
	int size = sizeof(Points)/sizeof(Points[0]);
	cout << "The smallest distance is " << closest(Points,size);
	return 0;
}
