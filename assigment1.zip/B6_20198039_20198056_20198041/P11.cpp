
#include <bits/stdc++.h>
using namespace std;

int MaximumSubsetSum(int arr[], int n)
{
    int prev_incl = arr[0];
    int prev_excl = 0;
    int curMaxExcl;


    for (int i = 1; i < n; i++)
    {

        if(prev_incl > prev_excl)
        {
            curMaxExcl=prev_incl;
        }
        else
        {
            curMaxExcl=prev_excl;
        }


        prev_incl = prev_excl + arr[i];
        prev_excl = curMaxExcl;
    }
    if(prev_incl>prev_excl)
    {
        return prev_incl;
    }
    else
        return prev_excl;
}
int main()
{
    int n;
    cout<<"please enter your array size: ";
    cin>>n;
    int arr[n];
    cout<<"please enter your array element:";
    for(int i=0; i<n; i++)
    {
        cin>>arr[i];
    }
    cout<<MaximumSubsetSum(arr, n);
}
