#include <iostream>

/* run this program using the console pauser or add your own getch, system("pause") or input loop */
#include <bits/stdc++.h>
using namespace std;
class Node
{
public:
 int val;

 Node **Forward;
Node(int val, int level)
{
 this->val = val;

 Forward = new Node*[level+1];

 memset(Forward, 0, sizeof(Node*)*(level+1));
}

};
class SkipList
{
 int max_level;

 float P;
 int level;
 Node *header;
public:
 

SkipList(int max_level, float P)
{
 this->max_level = max_level;
 this->P = P;
 level = 0;
 header = new Node(-1, max_level);
}

int randomLevel()
{
 float r = (float)rand()/RAND_MAX;
 int lvl = 0;
 while(r < P && lvl < max_level)
 {
  lvl++;
  r = (float)rand()/RAND_MAX;
 }
 return lvl;
}

Node* createNode(int val, int level)
{
 Node *node = new Node(val, level);
 return node;
}
void insertElement(int val)
{
 Node *cur = header;

 Node *update[max_level+1];
 memset(update, 0, sizeof(Node*)*(max_level+1));

 
 for(int i = level; i >= 0; i--)
 {
  while(cur->Forward[i] != NULL &&
   cur->Forward[i]->val < val)
   cur = cur->Forward[i];
  update[i] = cur;
 }

 
 cur = cur->Forward[0];

 if (cur == NULL || cur->val != val)
 {
  
  int randlev = randomLevel();

  if(randlev > level)
  {
   for(int i=level+1;i<randlev+1;i++)
    update[i] = header;

   
   level = randlev;
  }

  Node* node = createNode(val, randlev);

  for(int i=0;i<=randlev;i++)
  {
   node->Forward[i] = update[i]->Forward[i];
   update[i]->Forward[i] = node;
  }
  cout<<"Inserted key "<<val<<"\n";
 }
}

// Delete element from skip list
void deleteElement(int val)
{
 Node *cur = header;

 // create update array and initialize it
 Node *update[max_level+1];
 memset(update, 0, sizeof(Node*)*(max_level+1));

 for(int i = level; i >= 0; i--)
 {
  while(cur->Forward[i] != NULL &&
   cur->Forward[i]->val < val)
   cur = cur->Forward[i];
  update[i] = cur;
 }

 cur = cur->Forward[0];

 // If current node is target node
 if(cur != NULL and cur->val == val)
 {
  
  for(int i=0;i<=level;i++)
  {
   /* If at level i, next node is not target
   node, break the loop, no need to move
   further level */
   if(update[i]->Forward[i] != cur)
    break;

   update[i]->Forward[i] = cur->Forward[i];
  }

  // Remove levels having no elements
  while(level>0 &&
   header->Forward[level] == 0)
   level--;
  cout<<" deleted key "<<val<<"\n";
 }
}


void searchElement(int val)
{
    
 Node *cur = header;
int counter=0;
 
 for(int i = level; i >= 0; i--)
 {
  while(cur->Forward[i] &&
   cur->Forward[i]->val < val)
   cur = cur->Forward[i];

 }counter++;

 cur = cur->Forward[0];

 
 if(cur and cur->val== val)
  cout<<"value: "<<val<<"  search steps "<<counter<<"\n";
  else 
  cout<<"  -1"<<endl;
}

// Display skip list level wise
void getlayers()
{
 int count=0;
 for(int i=0;i<=level;i++)
 {
  Node *node = header->Forward[i];
  //cout<<" Level "<<i<<": ";
  while(node != NULL)
  {
   //cout<<node->val<<" ";
   node = node->Forward[i];
  }
  count++;
  
 }
 cout<<"  count "<<count<<endl;
}
void getspeclayers(int level)
{
  Node *node = header->Forward[level];
  cout<<" Level "<<level<<": ";
  while(node != NULL)
  {
   cout<<node->val<<" ";
   node = node->Forward[level];
  }
}
};

// Driver to test above code
int main()
{
 // Seed random number generator
 srand((unsigned)time(0));

 // create SkipList object with MAXLVL and P
 SkipList lst(3, 0.5);

 lst.insertElement(16);
 lst.insertElement(71);
 lst.insertElement(91);
 lst.insertElement(2);
 lst.insertElement(10);
 lst.insertElement(15);
 lst.insertElement(31);
 lst.insertElement(86);
 lst.insertElement(89);
 lst.insertElement(96);
 

 lst.searchElement(86);
lst.searchElement(16);
lst.searchElement(160);
 
 lst.getlayers();
 lst.getspeclayers(1);

}
